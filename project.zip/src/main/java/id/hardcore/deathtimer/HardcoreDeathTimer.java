package id.hardcore.deathtimer;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class HardcoreDeathTimer extends JavaPlugin implements Listener {
    private final Map<UUID, Long> deadlines = new HashMap<>();
    private final Map<UUID, Location> returnLocations = new HashMap<>();
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private final Map<UUID, Location> lastRoomLocations = new HashMap<>();
    private final Map<UUID, Boolean> internalTeleport = new HashMap<>();
    private final Map<UUID, Boolean> oldGravity = new HashMap<>();
    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        loadPlayerData();

        new BukkitRunnable() {
            @Override public void run() {
                for (UUID id : deadlines.keySet().toArray(new UUID[0])) {
                    Player player = Bukkit.getPlayer(id);
                    if (player != null && player.isOnline()) updatePlayer(player);
                }
            }
        }.runTaskTimer(this, 20L, 20L);

        for (Player player : Bukkit.getOnlinePlayers()) {
            if (isWaiting(player.getUniqueId())) {
                Bukkit.getScheduler().runTask(this, () -> sendToRoom(player));
            }
        }
        getLogger().info("HardcoreDeathTimer aktif.");
    }

    @Override
    public void onDisable() {
        for (BossBar bar : bars.values()) bar.removeAll();
        // Jangan biarkan pemain tetap tanpa gravitasi jika plugin dimatikan/reload.
        for (Player player : Bukkit.getOnlinePlayers()) player.setGravity(true);
        savePlayerData();
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        UUID id = player.getUniqueId();

        Location bed = player.getBedSpawnLocation();
        if (bed == null || bed.getWorld() == null) {
            bed = player.getWorld().getSpawnLocation();
            player.sendMessage("§e[HDT] Bed spawn tidak ditemukan; kamu akan kembali ke world spawn.");
        }
        returnLocations.put(id, bed.clone());

        long duration = Math.max(1, getConfig().getLong("wait-seconds", 900));
        deadlines.put(id, System.currentTimeMillis() + duration * 1000L);
        savePlayerData();
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (!isWaiting(player.getUniqueId())) return;

        Location room = getRoom();
        if (room == null) {
            getLogger().warning("Death Room belum diatur. Gunakan /hdt setroom.");
            return;
        }
        event.setRespawnLocation(room);
        Bukkit.getScheduler().runTask(this, () -> {
            if (player.isOnline() && isWaiting(player.getUniqueId())) {
                sendToRoom(player);
                player.sendMessage("§cKamu mati! §fTunggu §e15 menit§f sebelum kembali.");
            }
        });
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (!isWaiting(player.getUniqueId())) return;
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (player.isOnline() && isWaiting(player.getUniqueId())) sendToRoom(player);
        }, 2L);
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        UUID id = player.getUniqueId();
        if (!isWaiting(id) || event.getTo() == null) return;

        Location room = getRoom();
        if (room == null) return;
        Location to = event.getTo();
        // Radius berbentuk bola 3D: pemain boleh bergerak 5 blok ke segala arah.
        double radius = getConfig().getDouble("room-radius", 5.0);
        if (to.getWorld() != room.getWorld() || to.distanceSquared(room) > radius * radius) {
            Location safe = lastRoomLocations.getOrDefault(id, room).clone();
            safe.setYaw(to.getYaw());
            safe.setPitch(to.getPitch());
            event.setTo(safe);
        } else {
            lastRoomLocations.put(id, to.clone());
        }
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onTeleport(PlayerTeleportEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        if (isWaiting(id) && !internalTeleport.getOrDefault(id, false)) {
            event.setCancelled(true);
        }
    }

    private void sendToRoom(Player player) {
        Location room = getRoom();
        if (room == null) return;
        // Tanpa gravitasi: pemain melayang, tetapi tetap bisa menggerakkan karakter.
        player.setGravity(false);
        oldGravity.putIfAbsent(player.getUniqueId(), player.hasGravity());
        player.setGravity(false);
        player.setFallDistance(0f);
        teleportInternally(player, room);
        lastRoomLocations.put(player.getUniqueId(), room.clone());
        updatePlayer(player);
    }

    private void teleportInternally(Player player, Location location) {
        UUID id = player.getUniqueId();
        internalTeleport.put(id, true);
        player.teleport(location);
        internalTeleport.remove(id);
    }

    private void updatePlayer(Player player) {
        UUID id = player.getUniqueId();
        Long end = deadlines.get(id);
        if (end == null) return;

        long remaining = end - System.currentTimeMillis();
        if (remaining <= 0) {
            releasePlayer(player);
            return;
        }

        long total = Math.max(1, getConfig().getLong("wait-seconds", 900));
        double progress = Math.max(0.0, Math.min(1.0, (double) remaining / (total * 1000.0)));
        long seconds = (remaining + 999) / 1000;
        long minutes = seconds / 60;
        long secs = seconds % 60;

        BossBar bar = bars.computeIfAbsent(id, key ->
                Bukkit.createBossBar("§cWAKTU KEBANGKITAN", BarColor.RED, BarStyle.SOLID));
        bar.setTitle("§cWAKTU KEBANGKITAN §f" + String.format("%02d:%02d", minutes, secs));
        bar.setProgress(progress);
        if (!bar.getPlayers().contains(player)) bar.addPlayer(player);
    }

    private void releasePlayer(Player player) {
        UUID id = player.getUniqueId();
        Location destination = returnLocations.get(id);
        if (destination == null || destination.getWorld() == null) {
            destination = player.getWorld().getSpawnLocation();
        }
        player.setGravity(true);
        teleportInternally(player, destination);
        if (oldGravity.containsKey(id)) player.setGravity(oldGravity.remove(id));
        BossBar bar = bars.remove(id);
        if (bar != null) bar.removeAll();
        deadlines.remove(id);
        returnLocations.remove(id);
        lastRoomLocations.remove(id);
        savePlayerData();
        player.sendMessage("§aWaktu hukuman selesai! Kamu dikembalikan ke spawn.");
    }

    private boolean isWaiting(UUID id) {
        return deadlines.containsKey(id);
    }

    private Location getRoom() {
        ConfigurationSection section = getConfig().getConfigurationSection("death-room");
        if (section == null) return null;
        World world = Bukkit.getWorld(section.getString("world", ""));
        if (world == null) return null;
        return new Location(world, section.getDouble("x"), section.getDouble("y"),
                section.getDouble("z"), (float) section.getDouble("yaw"),
                (float) section.getDouble("pitch"));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("setroom")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Command ini harus dijalankan oleh pemain.");
                return true;
            }
            if (!sender.hasPermission("hdt.admin")) {
                sender.sendMessage("§cKamu tidak punya izin.");
                return true;
            }
            Location loc = player.getLocation();
            getConfig().set("death-room.world", loc.getWorld().getName());
            getConfig().set("death-room.x", loc.getX());
            getConfig().set("death-room.y", loc.getY());
            getConfig().set("death-room.z", loc.getZ());
            getConfig().set("death-room.yaw", loc.getYaw());
            getConfig().set("death-room.pitch", loc.getPitch());
            saveConfig();
            sender.sendMessage("§aDeath Room berhasil diatur di lokasimu sekarang.");
            return true;
        }
        sender.sendMessage("§eGunakan: /hdt setroom");
        return true;
    }

    private void loadPlayerData() {
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "players.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection players = data.getConfigurationSection("players");
        if (players == null) return;

        for (String key : players.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                long deadline = players.getLong(key + ".deadline");
                String worldName = players.getString(key + ".return.world");
                World world = Bukkit.getWorld(worldName == null ? "" : worldName);
                if (world == null) continue;
                Location back = new Location(world,
                        players.getDouble(key + ".return.x"),
                        players.getDouble(key + ".return.y"),
                        players.getDouble(key + ".return.z"),
                        (float) players.getDouble(key + ".return.yaw"),
                        (float) players.getDouble(key + ".return.pitch"));
                if (deadline > System.currentTimeMillis()) {
                    deadlines.put(id, deadline);
                    returnLocations.put(id, back);
                }
            } catch (IllegalArgumentException ignored) {}
        }
    }

    private void savePlayerData() {
        if (data == null) return;
        data.set("players", null);
        for (UUID id : deadlines.keySet()) {
            String path = "players." + id;
            data.set(path + ".deadline", deadlines.get(id));
            Location loc = returnLocations.get(id);
            if (loc == null || loc.getWorld() == null) continue;
            data.set(path + ".return.world", loc.getWorld().getName());
            data.set(path + ".return.x", loc.getX());
            data.set(path + ".return.y", loc.getY());
            data.set(path + ".return.z", loc.getZ());
            data.set(path + ".return.yaw", loc.getYaw());
            data.set(path + ".return.pitch", loc.getPitch());
        }
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Gagal menyimpan players.yml: " + e.getMessage());
        }
    }
}
