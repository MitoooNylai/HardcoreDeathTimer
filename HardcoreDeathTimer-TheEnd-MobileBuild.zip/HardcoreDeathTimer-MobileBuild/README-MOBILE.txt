BUILD DARI HP (TANPA PC)

1. Buka github.com di browser dan login.
2. Buat repository baru bernama HardcoreDeathTimer (Public atau Private).
3. Upload semua isi folder ZIP ini ke repository. Pastikan folder .github/workflows ikut ter-upload.
   Jika upload lewat web, upload file/folder project ke root repository.
4. Buka tab Actions > Build HardcoreDeathTimer.
5. Tekan Run workflow > Run workflow dan tunggu selesai (status hijau).
6. Buka build yang selesai, bagian Artifacts, unduh HardcoreDeathTimer-JAR.
7. Ekstrak artifact ZIP, ambil file .jar, upload ke server /plugins.
8. Restart server Paper.

Java build target: Java 21. Plugin ditargetkan untuk Paper 1.21.11.
Death Room: world_the_end, titik tengah 0.5,150,0.5, radius 5 blok, durasi 900 detik.
